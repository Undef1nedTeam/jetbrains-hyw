package dev.undefinedteam.obfuscator.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 启用控制流平坦化混淆。
 * <p>
 * 打在方法上时，对该方法启用控制流平坦化；
 * 打在类上时，对该类中所有方法启用控制流平坦化。
 * 控制流平坦化通过将代码的分支结构转换为 switch-dispatch 模式，
 * 使反编译后的代码逻辑难以阅读和理解。
 * </p>
 */
@Target({ElementType.METHOD, ElementType.TYPE})
public @interface FlowFlat {
}
