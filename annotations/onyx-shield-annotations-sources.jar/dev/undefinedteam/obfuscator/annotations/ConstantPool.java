package dev.undefinedteam.obfuscator.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 标记类启用常量池混淆。
 * <p>
 * 将此注解打在类上，混淆器将对该类的常量池进行混淆处理，
 * 增加逆向工程的难度。
 * </p>
 */
@Target(ElementType.TYPE)
public @interface ConstantPool {
}
