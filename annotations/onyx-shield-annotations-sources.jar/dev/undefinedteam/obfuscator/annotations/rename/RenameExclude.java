package dev.undefinedteam.obfuscator.annotations.rename;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 排除重命名混淆。
 * <p>
 * 打在方法、类或字段上，使其名称免于被重命名混淆器修改。
 * 适用于需要通过反射、序列化、JNI 或其他外部机制按名称访问的元素。
 * </p>
 *
 * @see RenameEntriesExclude
 */
@Target({ElementType.METHOD, ElementType.TYPE, ElementType.FIELD})
public @interface RenameExclude {
}
