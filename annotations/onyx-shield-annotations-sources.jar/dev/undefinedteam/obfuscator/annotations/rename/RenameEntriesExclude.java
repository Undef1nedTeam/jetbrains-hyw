package dev.undefinedteam.obfuscator.annotations.rename;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 排除类下面的 全部methods 或者是 全部fields
 * <p>
 * 打在类上
 * <li>打上 {@link dev.undefinedteam.obfuscator.annotations.AllFields} 就是排除全部fields</li>
 * <li>打上 {@link dev.undefinedteam.obfuscator.annotations.AllMethods} 就是排除全部methods</li>
 * 不会被Renamer修改
 * </p>
 *
 * @see RenameExclude
 * @see dev.undefinedteam.obfuscator.annotations.AllFields
 * @see dev.undefinedteam.obfuscator.annotations.AllMethods
 */
@Target({ElementType.TYPE})
public @interface RenameEntriesExclude {
}
