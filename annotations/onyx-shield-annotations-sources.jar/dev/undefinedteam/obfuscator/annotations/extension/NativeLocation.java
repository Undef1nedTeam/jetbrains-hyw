package dev.undefinedteam.obfuscator.annotations.extension;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 指定原生代码中类、字段或方法的定位路径。
 * <p>
 * 提供一个 API 实现，用于在原生代码中通过 {@code find_class}、{@code find_method}、{@code find_field} 等
 * cni 函数定位 Java 类、字段和方法。打上此注解后，原生代码将使用指定的
 * {@link #value()} 路径来查找对应的 Java 元素。
 * </p>
 *
 * @see NativeExtension
 */
@Target({ElementType.FIELD, ElementType.TYPE, ElementType.METHOD})
public @interface NativeLocation {
    /**
     * @return 原生代码中用于定位的路径标识
     */
    String value();
}
