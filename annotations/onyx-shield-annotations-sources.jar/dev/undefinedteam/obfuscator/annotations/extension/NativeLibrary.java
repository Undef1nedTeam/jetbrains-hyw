package dev.undefinedteam.obfuscator.annotations.extension;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 标记字段为原生库引用。
 * <p>
 * 打在字段上，表示该字段引用的是一个原生库（.lib / .a）文件，
 * 将在原生扩展构建时被链接使用。
 * </p>
 *
 * @see NativeExtension
 */
@Target({ElementType.FIELD})
public @interface NativeLibrary {
}
