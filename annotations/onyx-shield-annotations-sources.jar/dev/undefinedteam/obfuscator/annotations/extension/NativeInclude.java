package dev.undefinedteam.obfuscator.annotations.extension;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 标记字段为原生代码的 include 头文件。
 * <p>
 * 打在字段上，表示该字段引用的是一个需要被插入到生成的原生代码中的 include 文件。
 * </p>
 *
 * @see NativeExtension
 * @see NativeSource
 */
@Target({ElementType.FIELD})
public @interface NativeInclude {
}
