package dev.undefinedteam.obfuscator.annotations.extension;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 配置原生代码扩展项目信息。
 * <p>
 * 打在类上，用于定义一个原生扩展（Native Extension）项目的构建配置，
 * 包括项目名称、目录结构、源文件路径、头文件路径、静态库路径以及链接库等。
 * </p>
 *
 * @see NativeSource
 * @see NativeInclude
 * @see NativeLibrary
 */
@Target({ElementType.TYPE})
public @interface NativeExtension {
    /**
     * @return 原生扩展项目名称
     */
    String project_name();

    /**
     * @return 原生扩展项目的根目录路径
     */
    String project_dir();

    /**
     * 以 {@link #project_dir()} 为基准的相对路径。
     *
     * @return 源文件目录列表
     */
    String[] sources_dir();

    /**
     * 以 {@link #project_dir()} 为基准的相对路径。
     *
     * @return 头文件包含目录列表
     */
    String[] includes_dir();

    /**
     * 以 {@link #project_dir()} 为基准的相对路径。
     *
     * @return 静态库目录列表
     */
    String[] static_libraries_dir();

    /**
     * @return C++ 标准版本号，默认为 23
     */
    int cppVersion() default 23;

    /**
     * @return 需要链接的库名称列表
     */
    String[] link_libraries();
}
