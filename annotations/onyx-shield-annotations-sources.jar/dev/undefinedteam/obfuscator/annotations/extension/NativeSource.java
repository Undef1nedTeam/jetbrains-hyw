package dev.undefinedteam.obfuscator.annotations.extension;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 标记字段为原生源文件引用。
 * <p>
 * 打在字段上，表示该字段引用的是一个原生源代码文件（如 .cpp / .c），
 * 将被包含到原生扩展项目的构建中。
 * </p>
 *
 * @see NativeExtension
 */
@Target({ElementType.FIELD})
public @interface NativeSource {
    /**
     * @return 源文件路径
     */
    String value();
}
