package dev.undefinedteam.obfuscator.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 排除类中全部字段的混淆处理。
 * <p>
 * 将此注解打在类上，可使该类中所有字段免于被混淆器处理。
 * 适用于需要保留字段名称不变的场景，例如序列化、反射调用等。
 * </p>
 *
 * @see AllMethods
 */
@Target({ElementType.TYPE})
public @interface AllFields {
}
