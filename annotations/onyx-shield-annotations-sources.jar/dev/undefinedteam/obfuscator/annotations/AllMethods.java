package dev.undefinedteam.obfuscator.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 排除类中全部方法的混淆处理。
 * <p>
 * 将此注解打在类上，可使该类中所有方法免于被混淆器处理。
 * 适用于需要保留方法签名不变的场景，例如反射调用、JNI 回调等。
 * </p>
 *
 * @see AllFields
 */
@Target({ElementType.TYPE})
public @interface AllMethods {
}
