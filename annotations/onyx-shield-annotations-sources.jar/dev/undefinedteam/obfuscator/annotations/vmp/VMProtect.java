package dev.undefinedteam.obfuscator.annotations.vmp;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 启用 VMProtect 保护。
 * <p>
 * 打在方法或类上，在生成的原生代码中插入 {@code VMProtectBegin} / {@code VMProtectEnd}
 * 标记对，使 VMProtect 工具对标记范围内的原生代码进行保护处理。
 * </p>
 * <p>
 * 可通过 {@link #value()} 指定标记名称，通过 {@link #type()} 选择保护类型。
 * </p>
 *
 * @see Protection
 * @see dev.undefinedteam.obfuscator.annotations.themida.NativeVirtualization
 * @see dev.undefinedteam.obfuscator.annotations.natives.AutoNative
 */
@Target({ElementType.METHOD, ElementType.TYPE})
public @interface VMProtect {
    /**
     * @return VMProtect 标记名称，默认为 {@code "MarkerName"}
     */
    String value() default "MarkerName";

    /**
     * @return 保护类型
     * @see Protection
     */
    Protection type() default Protection.NORMAL;

    /**
     * VMProtect 保护类型枚举。
     * <ul>
     *   <li>{@link #NORMAL} — 普通保护（代码替换）</li>
     *   <li>{@link #MUTATION} — 代码变异保护</li>
     *   <li>{@link #ULTRA} — 超级保护（变异 + 虚拟化混合）</li>
     *   <li>{@link #VIRTUALIZATION} — 完全虚拟化保护</li>
     * </ul>
     */
    enum Protection {
        /** 普通保护（代码替换） */
        NORMAL,
        /** 代码变异保护 */
        MUTATION,
        /** 超级保护（变异 + 虚拟化混合） */
        ULTRA,
        /** 完全虚拟化保护 */
        VIRTUALIZATION
    }
}
