package dev.undefinedteam.obfuscator.annotations.natives;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 启用原生代码数组栈模式。
 * <p>
 * 打在方法上，使生成的原生代码使用 {@code stack_frame.hpp} 中定义的数组栈
 * 替代默认的 C 栈进行操作数管理。此模式更加通用，能处理更复杂的字节码模式，
 * 但相比直接使用 C 栈会增加一定的运行时开销，同时也提升了逆向分析的难度。
 * </p>
 *
 * @see AutoNative
 */
@Target({ElementType.METHOD})
public @interface NativeArrayStack {
}
