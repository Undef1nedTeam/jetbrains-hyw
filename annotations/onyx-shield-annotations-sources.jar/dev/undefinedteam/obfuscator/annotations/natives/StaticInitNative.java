package dev.undefinedteam.obfuscator.annotations.natives;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 标记类的静态初始化块（{@code <clinit>}）进行 Native 化。
 * <p>
 * 打在类上，混淆器将该类的静态初始化方法转换为原生代码实现，
 * 保护静态字段初始化逻辑和静态代码块中的敏感操作。
 * </p>
 *
 * @see AutoNative
 */
@Target({ElementType.TYPE})
public @interface StaticInitNative {
}
