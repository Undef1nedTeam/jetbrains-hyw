package dev.undefinedteam.obfuscator.annotations.natives;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 标记方法或类启用自动 Native 化混淆。
 * <p>
 * 将 Java 方法的字节码转换为原生（C/C++）代码实现，通过 JNI 调用执行，
 * 从而将方法逻辑从 Java 层转移到原生层，极大增加逆向工程的难度。
 * </p>
 * <ul>
 *   <li>打在方法上：仅对该方法执行 Native 化</li>
 *   <li>打在类上：对该类中所有方法执行 Native 化</li>
 *   <li>打在字段上：对该字段相关的访问逻辑执行 Native 化</li>
 * </ul>
 * <p>
 * 可结合以下注解进一步增强保护强度：
 * </p>
 * <ul>
 *   <li>{@link dev.undefinedteam.obfuscator.annotations.themida.NativeVirtualization} — Themida 虚拟化保护</li>
 *   <li>{@link dev.undefinedteam.obfuscator.annotations.vmp.VMProtect} — VMProtect 虚拟化保护</li>
 * </ul>
 *
 * @see NativeExclude
 * @see NativeInline
 */
@Target({ElementType.METHOD, ElementType.TYPE, ElementType.FIELD})
public @interface AutoNative {
}
