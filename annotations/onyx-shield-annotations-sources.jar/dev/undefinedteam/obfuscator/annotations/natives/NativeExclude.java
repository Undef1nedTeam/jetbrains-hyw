package dev.undefinedteam.obfuscator.annotations.natives;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 排除 Native 化混淆。
 * <p>
 * 打在方法、类或字段上，使其免于被 {@link AutoNative} 转换为原生代码。
 * 当类级别打了 {@link AutoNative} 时，可使用此注解排除特定方法或字段。
 * </p>
 *
 * @see AutoNative
 */
@Target({ElementType.METHOD, ElementType.TYPE, ElementType.FIELD})
public @interface NativeExclude {
}
