package dev.undefinedteam.obfuscator.annotations.natives;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 类定义与 JNI_OnLoad 中。
 * <p>
 * 打在类上，混淆器将为该类的字节码在 {@code JNI_OnLoad} 里面进行DefineClass
 * </p>
 *
 * @see AutoNative
 */
@Target({ElementType.TYPE})
public @interface NativeDefine {
}
