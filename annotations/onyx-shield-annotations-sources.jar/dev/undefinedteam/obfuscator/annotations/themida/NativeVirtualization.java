package dev.undefinedteam.obfuscator.annotations.themida;

import dev.undefinedteam.obfuscator.annotations.natives.AutoNative;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 启用 Themida 虚拟化保护。
 * <p>
 * 需要与 {@link AutoNative} 注解配合使用。在方法被 Native 化后，
 * 生成的原生代码将由 Themida 进行虚拟化保护，使其在自定义虚拟机中执行，
 * 极大提升逆向工程的难度。
 * </p>
 * <p>
 * 可通过 {@link #value()} 指定虚拟机类型，不同类型在复杂度和执行速度之间
 * 有不同的权衡。默认为 {@link VirtualMachine#NONE}（不启用虚拟化）。
 * </p>
 *
 * @see AutoNative
 * @see VirtualMachine
 * @see dev.undefinedteam.obfuscator.annotations.vmp.VMProtect
 */
@Target({ElementType.METHOD, ElementType.TYPE})
public @interface NativeVirtualization {
    /**
     * 指定 Themida 虚拟机类型。
     *
     * @return 虚拟化引擎类型
     * @see VirtualMachine
     */
    VirtualMachine value() default VirtualMachine.NONE;
}
