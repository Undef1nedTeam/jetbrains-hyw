package dev.undefinedteam.obfuscator.annotations.themida;

// Themida VirtualMachines
public enum VirtualMachine {
    NONE(0, 100),
    MUTATE_ONLY(0, 100),
    TIGER_WHITE(15, 96),
    TIGER_RED(21, 95),
    TIGER_BLACK(23, 91),
    FISH_WHITE(10, 90),
    FISH_RED(20, 85),
    FISH_BLACK(35, 4),
    PUMA_WHITE(80, 16),
    PUMA_RED(87, 8),
    PUMA_BLACK(89, 3),
    SHARK_WHITE(80, 21),
    SHARK_RED(85, 15),
    SHARK_BLACK(93, 1),
    DOLPHIN_WHITE(19, 88),
    DOLPHIN_RED(38, 74),
    DOLPHIN_BLACK(45, 72),
    EAGLE_WHITE(92, 2),
    EAGLE_RED(93, 1),
    EAGLE_BLACK(96, 1),
    LION_WHITE(43, 76),
    LION_RED(53, 74),
    LION_BLACK(60, 62);

    public final int complexity, speed;

    VirtualMachine(int complexity, int speed) {
        this.complexity = complexity;
        this.speed = speed;
    }
}
