package dev.undefinedteam.obfuscator.annotations.array;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 排除局部变量转数组混淆。
 * <p>
 * 打在类上时，排除该类中所有方法的局部变量转数组混淆；
 * 打在方法上时，仅排除该方法的局部变量转数组操作。
 * </p>
 *
 * @see LocalsToArray
 */
@Target({ElementType.TYPE, ElementType.METHOD})
public @interface LocalsToArrayExclude {
}
