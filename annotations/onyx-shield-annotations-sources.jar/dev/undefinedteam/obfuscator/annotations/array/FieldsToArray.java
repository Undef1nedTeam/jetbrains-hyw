package dev.undefinedteam.obfuscator.annotations.array;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 启用字段转数组混淆。
 * <p>
 * 打在类上时，将该类中所有字段合并存储到数组中；
 * 打在字段上时，仅对该字段执行转数组操作。
 * 此混淆会将多个字段替换为数组索引访问，增加逆向分析难度。
 * </p>
 *
 * @see FieldsToArrayExclude
 */
@Target({ElementType.TYPE, ElementType.FIELD})
public @interface FieldsToArray {
}
