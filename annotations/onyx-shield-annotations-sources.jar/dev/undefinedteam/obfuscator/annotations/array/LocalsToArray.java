package dev.undefinedteam.obfuscator.annotations.array;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 启用局部变量转数组混淆。
 * <p>
 * 打在类上时，对该类中所有方法的局部变量执行转数组操作；
 * 打在方法上时，仅对该方法的局部变量执行转数组操作。
 * 此混淆会将方法内的局部变量合并存储到数组中，通过索引访问替代直接变量引用。
 * </p>
 *
 * @see LocalsToArrayExclude
 */
@Target({ElementType.TYPE, ElementType.METHOD})
public @interface LocalsToArray {
}
