package dev.undefinedteam.obfuscator.annotations.array;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 排除字段转数组混淆。
 * <p>
 * 打在类上时，排除该类中所有字段的转数组混淆；
 * 打在字段上时，仅排除该字段的转数组操作。
 * </p>
 *
 * @see FieldsToArray
 */
@Target({ElementType.TYPE, ElementType.FIELD})
public @interface FieldsToArrayExclude {
}
