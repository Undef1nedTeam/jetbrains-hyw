package dev.undefinedteam.obfuscator.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

/**
 * 排除 InvokeDynamic (Indy) 混淆处理。
 * <p>
 * 打在方法、类或字段上，使其免于 InvokeDynamic 指令混淆。
 * InvokeDynamic 混淆会将普通方法调用替换为 {@code invokedynamic} 指令，
 * 使用此注解可排除特定目标，避免兼容性问题。
 * </p>
 */
@Target({ElementType.METHOD, ElementType.TYPE, ElementType.FIELD})
public @interface IndyExclude {
}
